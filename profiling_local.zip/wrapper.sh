#!/usr/bin/env bash
set -euo pipefail

# --- CONFIG ---
# Edit this to the python command that runs your descriptor pipeline.
# Placeholders:
#   $XYZ_FILE : path to the .xyz file (transferred into job sandbox)
#   $MODE     : "torch" or "numpy"
#
# EXAMPLE (edit to your actual entrypoint & flags):
# TARGET_CMD='python your_pipeline.py --input "$XYZ_FILE" $( [ "$MODE" = "torch" ] && echo "--use-torch" || echo "--no-torch" )'
#
# If your code auto-detects torch vs numpy by env var, you can use:
#   export ANISOAP_BACKEND=$MODE
#   TARGET_CMD='python your_pipeline.py --input "$XYZ_FILE"'
#
TARGET_CMD='python your_pipeline.py --input "$XYZ_FILE" $( [ "$MODE" = "torch" ] && echo "--use-torch" || echo "--no-torch" )'

# --- RUNTIME ---
XYZ_FILE="$1"
MODE="$2"           # "torch" or "numpy"
JOBTAG="$(basename "${XYZ_FILE%.*}")_${MODE}"
OUTDIR="results"
mkdir -p "$OUTDIR"

# If on docker:python:3.10 image, ensure pip packages if needed (requires outbound net; otherwise ship a venv tarball instead).
# You can comment pip installs out if your code does not need extras beyond stdlib.
if [ "${PIP_INSTALL:-0}" = "1" ]; then
  python -m pip install --upgrade pip >/dev/null 2>&1 || true
  if [ "$MODE" = "torch" ]; then
    # CPU-only torch
    python -m pip install --no-cache-dir torch --index-url https://download.pytorch.org/whl/cpu >/dev/null 2>&1 || true
  fi
  # Add your other deps here, or ship them via a tarball/venv.
  # python -m pip install -r requirements_min.txt >/dev/null 2>&1 || true
fi

# Record environment for reproducibility
python - <<'PY'
import platform, sys, pkgutil, json, os, time
info = {
  "python": sys.version,
  "platform": platform.platform(),
  "mode": os.environ.get("MODE",""),
  "cwd": os.getcwd(),
  "time": time.ctime(),
  "installed": sorted([m.name for m in pkgutil.iter_modules()])
}
print(json.dumps(info, indent=2))
PY

# Wall clock + cProfile (per-function) + pstats text report
/usr/bin/time -f "%e" -o "${OUTDIR}/${JOBTAG}.wall" python - <<'PY' "$XYZ_FILE" "$MODE" "$TARGET_CMD" "$JOBTAG"
import os, sys, shlex, time, cProfile, pstats, io, subprocess, resource

xyz_file = sys.argv[1]
mode = sys.argv[2]
target_cmd_template = sys.argv[3]
jobtag = sys.argv[4]

# Assemble the concrete command by expanding template with env-like placeholders
cmd = target_cmd_template.replace("$XYZ_FILE", xyz_file).replace("$MODE", mode)

# If your target is a Python script and you want *that* process profiled, you need to run it inside this interpreter.
# For generality, we will wrap the *callable* path: you can keep the external process call for now and only wall-clock is captured,
# OR make your your_pipeline.py importable and call it directly under cProfile.
#
# Default: launch as a subprocess and collect wall-clock + RSS. Also run a tiny no-op cProfile to generate a file (so tooling downstream is simpler).
#
start = time.perf_counter()
usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
ret = subprocess.run(cmd, shell=True)
elapsed = time.perf_counter() - start
usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)

# Save simple metrics
os.makedirs("results", exist_ok=True)
with open(f"results/{jobtag}.metrics.json", "w") as f:
    f.write("{\n")
    f.write(f"  \"elapsed_s\": {elapsed:.6f},\n")
    f.write(f"  \"max_rss_kb\": {usage_after.ru_maxrss},\n")
    f.write(f"  \"inblock\": {usage_after.ru_inblock},\n")
    f.write(f"  \"oublock\": {usage_after.ru_oublock},\n")
    f.write(f"  \"exit_code\": {ret.returncode}\n")
    f.write("}\n")

# Generate a tiny cProfile file (placeholder) so downstream scripts don't break if you didn't run in-process profiling.
pr = cProfile.Profile()
pr.enable(); pr.disable()
pr.dump_stats(f"results/{jobtag}.prof")

# Also emit a human-readable pstats summary (will be mostly empty unless you adapt to in-process)
s = io.StringIO()
ps = pstats.Stats(pr, stream=s).sort_stats(pstats.SortKey.CUMULATIVE)
ps.print_stats(20)
with open(f"results/{jobtag}.pstats.txt","w") as f:
    f.write(s.getvalue())

print(f"[INFO] Completed '{cmd}' with return code {ret.returncode} in {elapsed:.3f}s")
PY

# Collate quick timing line
WALL=$(cat "${OUTDIR}/${JOBTAG}.wall" || echo "NA")
echo "${JOBTAG},${XYZ_FILE},${MODE},${WALL}" >> timings.csv

echo "[OK] Job ${JOBTAG} finished."
