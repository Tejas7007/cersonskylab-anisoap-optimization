import sys
def count_species(path):
    species=set()
    with open(path,'r') as f:
        lines=f.read().strip().splitlines()
    for line in lines[2:]:
        if not line.strip(): continue
        species.add(line.split()[0])
    return len(species)

if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(p, count_species(p))
