# CHTC Profiling Harness (HTCondor)

## What this does
- Runs your Python pipeline on each .xyz with *and* without torch.
- Captures wall-clock time, a placeholder cProfile file, and basic resource stats.
- Provides an analyzer to compare observed timings against quadratic scaling in #species.

## One-time setup on AP (ap2001)
```bash
ssh tdahiya2@ap2001.chtc.wisc.edu
mkdir -p ~/chtc_profiling && cd ~/chtc_profiling
```

## Upload the package + input files
On your laptop (same folder as the ZIP you downloaded):
```bash
scp chtc_profiling.zip tdahiya2@ap2001.chtc.wisc.edu:~/chtc_profiling/
scp one_species.xyz benzenes.xyz three_species.xyz four_species.xyz ellipsoids.xyz tdahiya2@ap2001.chtc.wisc.edu:~/chtc_profiling/
```
Then on the AP:
```bash
cd ~/chtc_profiling
unzip -o chtc_profiling.zip
```

## Edit wrapper.sh to call your real code
Open `wrapper.sh` and set `TARGET_CMD` to your actual entrypoint, e.g.:
```bash
TARGET_CMD='python -m anisoap.cli --input "$XYZ_FILE" $( [ "$MODE" = "torch" ] && echo "--use-torch" || echo "--no-torch" )'
```

If your code toggles backend via env var, do:
```bash
export ANISOAP_BACKEND=$MODE
TARGET_CMD='python -m anisoap.cli --input "$XYZ_FILE"'
```

## Submit to HTCondor
```bash
chmod +x wrapper.sh
condor_submit chtc_profile.submit
condor_q
```
Outputs will land in `results/` and `timings.csv` in the job sandbox. Use `condor_wait logs/*.log` to wait until done.

## Analyze scaling (on AP)
```bash
python analyze_scaling.py --timings timings.csv
```

## Notes
- The submit file uses Docker universe with `python:3.10`. If outbound internet is blocked on execute nodes, keep `PIP_INSTALL=0` and ship a tarballed venv instead.
- cProfile currently profiles only the tiny launcher. To profile *inside* your code, import your pipeline as a function and execute under cProfile in `wrapper.sh` (advanced). For most timing-based scaling checks, wall clock is enough.
