import json, os, glob, math, argparse
from collections import defaultdict

def count_species_from_xyz(path):
    # Simple XYZ parser: second line possibly comment; species from column 1 (symbol)
    species = set()
    with open(path, "r") as f:
        lines = f.read().strip().splitlines()
    # Skip first two lines; then each atom: "Sym x y z"
    for line in lines[2:]:
        if not line.strip(): continue
        sym = line.split()[0]
        species.add(sym)
    return len(species)

def load_timings(csv_path):
    rows = []
    with open(csv_path,"r") as f:
        for line in f:
            line=line.strip()
            if not line or "," not in line: continue
            jobtag, xyz, mode, wall = line.split(",")
            try:
                wall = float(wall)
            except:
                wall = float("nan")
            rows.append((jobtag, xyz, mode, wall))
    return rows

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--timings", default="timings.csv")
    ap.add_argument("--root", default=".")
    args = ap.parse_args()

    rows = load_timings(args.timings)
    by_mode = defaultdict(list)
    for jobtag, xyz, mode, wall in rows:
        sp = count_species_from_xyz(xyz)
        by_mode[mode].append((sp, xyz, wall))

    print("\n=== Scaling Check (Expect ~quadratic in #species) ===")
    for mode, entries in by_mode.items():
        entries = sorted(entries)  # by species count
        print(f"\n[{mode}]")
        base = None
        for sp, xyz, wall in entries:
            if math.isnan(wall):
                print(f"  {xyz} (species={sp}): wall=NA")
                continue
            if base is None:
                base = (sp, wall)
                print(f"  {xyz} (species={sp}): {wall:.4f}s  [baseline]")
            else:
                sp0, w0 = base
                expected = w0 * (sp/sp0)**2
                ratio = wall / expected if expected>0 else float('nan')
                flag = "OK" if 0.7 <= ratio <= 1.4 else ("SLOW" if ratio>1.4 else "FAST")
                print(f"  {xyz} (species={sp}): {wall:.4f}s  | expected~{expected:.4f}s | ratio={ratio:.2f} -> {flag}")
        print("  Note: ratio>1.4 suggests worse-than-quadratic scaling.")

if __name__ == "__main__":
    main()
